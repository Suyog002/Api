function ner() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i=0;

            for (var i in myObj.articles) {
                if (i <= 0) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str2 ='<div class="fh5co_suceefh5co_height"><img src="'+ imgurl +'" alt="img"/><div class="fh5co_suceefh5co_height_position_absolute"></div><div class="fh5co_suceefh5co_height_position_absolute_font"><div class=""><a href="#" class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;Sep 14, 2020</a></div><div class=""><a href="'+url +'" class="fh5co_good_font"> '+ ttl +' </a></div></div></div>'
            
                document.getElementById("main1").innerHTML +=str2;
                }
                else if (i <=1) {
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str3 = '<div class="fh5co_suceefh5co_height_2"><img src="'+ imgurl +'" alt="img"/><div class="fh5co_suceefh5co_height_position_absolute"></div><div class="fh5co_suceefh5co_height_position_absolute_font_2"><div class=""><a href="#" class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;Sep 14, 2020 </a></div><div class=""><a href="'+ url +'" class="fh5co_good_font_2"> '+ ttl+' </a></div></div></div>'
                document.getElementById("main2").innerHTML +=str3;
                } 
                else if(i <=2){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str4 = '<div class="fh5co_suceefh5co_height_2"><img src="'+ imgurl +'" alt="img"/><div class="fh5co_suceefh5co_height_position_absolute"></div><div class="fh5co_suceefh5co_height_position_absolute_font_2"><div class=""><a href="#" class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;Sep 14, 2020 </a></div><div class=""><a href="'+ url +'" class="fh5co_good_font_2"> '+ ttl+' </a></div></div></div>' 
                document.getElementById("main3").innerHTML +=str4;
                }
                else if(i <=3){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str5 = '<div class="fh5co_suceefh5co_height_2"><img src="'+ imgurl +'" alt="img"/><div class="fh5co_suceefh5co_height_position_absolute"></div><div class="fh5co_suceefh5co_height_position_absolute_font_2"><div class=""><a href="#" class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;Sep 14, 2020 </a></div><div class=""><a href="'+ url +'" class="fh5co_good_font_2"> '+ ttl+' </a></div></div></div>'
                document.getElementById("main4").innerHTML +=str5;
                }
                else if(i <=4){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str6 = '<div class="fh5co_suceefh5co_height_2"><img src="'+ imgurl +'" alt="img"/><div class="fh5co_suceefh5co_height_position_absolute"></div><div class="fh5co_suceefh5co_height_position_absolute_font_2"><div class=""><a href="#" class="color_fff"> <i class="fa fa-clock-o"></i>&nbsp;&nbsp;Sep 14, 2020 </a></div><div class=""><a href="'+ url +'" class="fh5co_good_font_2"> '+ ttl+' </a></div></div></div>' 
                document.getElementById("main5").innerHTML +=str6;
                }
            }

        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

ner();

function slide1() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i=0;

            for (var i in myObj.articles) {
                if (i <= 0) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str1 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slide1").innerHTML +=str1;
                }
                else if (i <=1) {
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                
                st2 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slide2").innerHTML +=st2;
                } 
                else if(i <=2){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                st3 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slide3").innerHTML +=st3;
                }
                else if(i <=3){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str4 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slide4").innerHTML +=str4;
                }
                else if(i <=4){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str5 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slide5").innerHTML +=str5;
                }
            }

        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=us&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

slide1();

function slider1() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i=0;

            for (var i in myObj.articles) {
                if (i <= 0) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str1 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slider1").innerHTML +=str1;
                }
                else if (i <=1) {
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                st2 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slider2").innerHTML +=st2;
                } 
                else if(i <=2){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                st3 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slider3").innerHTML +=st3;
                }
                else if(i <=3){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str4 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slider4").innerHTML +=str4;
                }
                else if(i <=4){
                ttl = myObj.articles[i].title;
                imgurl = myObj.articles[i].image;
                str5 ='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+ imgurl +'" alt=""/></div><div><a href="'+ url +'" class="d-block fh5co_small_post_heading"><span class="">'+ ttl +'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>' 
                document.getElementById("main-slider5").innerHTML +=str5;
                }
            }
        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&topic=breaking-news&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

slider1();

//Entertainment

function nextweb() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i;

            for (var i in myObj.articles) {
                if (i <= 3) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str = '<div class="col-lg-3 col-md-6"><div class="choice_item"><img class="img-fluid" src="'+ imgurl + '" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url + '" target="_blank">Entertainment</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Sep 14, 2020</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url +'"><h4>'+ ttl +'</h4></a><p class="text1">'+ des +'</p></div></div></div>'

                document.getElementById("forth").innerHTML += str;

                }

            }

        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&topic=entertainment&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

nextweb();
  
//Time of INDIA Latest News

function webym() {
	
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i;

            for (var i in myObj.articles) {
                if (i <= 3) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str=' <div class="media"><div class="d-flex"><img class="img-fluid" src="'+ imgurl +'" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"></div><div class="media-body"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url +'" target="_blank">TOI</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Sep 14, 2018</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url +'"><h4>'+ ttl +'</h4></a><p class="text1">'+ des +'</p></div></div></div>'
                document.getElementById("rit").innerHTML += str;

                }

            }

        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/search?q=The Times of India&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

webym();

//science
function verge() {


    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i;

            for (var i in myObj.articles) {
                if (i <= 5) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                // str = '<div class="col-lg-3 col-md-6"><div class="choice_item"><img class="img-fluid" src="'+ imgurl + '" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url + '" target="_blank">Gadgets</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Feb 24, 2020</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url +'"><h4>'+ ttl +'</h4></a><p>'+ des +'</p></div></div></div>'
                str ='<div class="col-lg-6 col-sm-6"><div class="choice_item small"><img class="img-fluid" src="'+ imgurl +'" alt=""><div class="choice_text"><a href="' + url + '"><h4>'+ ttl +'</h4></a><div class="date"><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Sep 14, 2018</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div></div></div></div>'
                document.getElementById("first").innerHTML += str;
                }
                else if(i <= 7){
                    url1 = myObj.articles[i].url;
                ttl1 = myObj.articles[i].title;
                des1 = myObj.articles[i].description;
                imgurl1 = myObj.articles[i].image;

                str1 ='<div class="choice_item"><img class="img-fluid" src="'+ imgurl1 +'" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url1 +'">Sceince</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Feb 28, 2018</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url1 +'"><h4>'+ ttl1 +'</h4></a><p class="text1">'+ des1 +'</p></div></div></div>'
                document.getElementById("seco").innerHTML +=str1;

                }
                
            }
        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&topic=science&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}

verge();

//Technology
function belo() {


    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i;

            for (var i in myObj.articles) {
                if (i <= 1) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str = '<div class="col-sm-6"><div class="choice_item"><img class="img-fluid" src="'+ imgurl +'" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url +'">Technology</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Sep 14, 2018</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url +'"><h4>'+ ttl +'</h4></a><p class="text1">'+ des +'</p></div></div></div>'
                document.getElementById("flip1").innerHTML += str;

                }
            }

        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&topic=technology&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}
belo();

//Business
function owl1() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            var ttl = "",
                url = "",
                des = "",
                imgurl = "";

            var str, i;
            for (var i in myObj.articles) {
                if (i <= 3) {
                url = myObj.articles[i].url;
                ttl = myObj.articles[i].title;
                des = myObj.articles[i].description;
                imgurl = myObj.articles[i].image;

                str = '<img class="img-fluid" src="'+ imgurl +'" alt=""><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url +'">Business</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>Sep 14, 2018</a><a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i>05</a></div><a href="'+ url +'"><h4>'+ ttl +'</h4></a><p class="text1">'+ des +'</p></div></div>'								
                document.getElementById("flow1").innerHTML += str;
                }
            }
        }
    };
    xmlhttp.open("GET", "https://gnews.io/api/v4/top-headlines?country=in&topic=business&token=d2ae7f9ba90d44f86d9debd61bf307be", true);
    xmlhttp.send();

}
owl1();

  async function cato1() {
    const URL = `https://gnews.io/api/v4/top-headlines?country=in&topic=breaking-news&token=d2ae7f9ba90d44f86d9debd61bf307be`;
     try {
     const fetchResult = fetch(URL)
     const response = await fetchResult;
     const jsonData = await response.json();
     console.log(jsonData);
     
     var ttl = "",
     url = "",
     des = "",
     imgurl = "";
     var str, i=1;
     for (var i in jsonData.articles)
     {
     if(i <=8){
         url = jsonData.articles[i].url;
     ttl = jsonData.articles[i].title;
     des = jsonData.articles[i].description;
     imgurl = jsonData.articles[i].image;
     str1= '<a href="#" class="footer_img_post_6"><img src="'+ imgurl+'" alt="img"/></a>'
     document.getElementById("foot1").innerHTML += str1;
     }
         
     }							
     } catch(e){
     throw Error(e);
     }
   }
   cato1();