
//Main blog
async function asub() {
 const URL = `https://gnews.io/api/v4/top-headlines?country=in&topic=business&token=d2ae7f9ba90d44f86d9debd61bf307be`;
  try {
  const fetchResult = fetch(URL)
  const response = await fetchResult;
  const jsonData = await response.json();
  console.log(jsonData);
  
  var ttl = "",
  url = "",
  des = "",
  imgurl = "";
  aut= "";
  var str, i;
  for (var i in jsonData.articles)
  {
  if(i <=10){
      url = jsonData.articles[i].url;
  ttl = jsonData.articles[i].title;
  des = jsonData.articles[i].description;
  imgurl = jsonData.articles[i].image;
  aut= jsonData.articles[i].source.name
 
  str=' <div class="media"><div class="d-flex fh5co_news_img"><img class="img-fluid" src="'+ imgurl +'" alt="" onerror="this.onerror=null;this.src="http://example.com/existent-image.jpg"></div><div class="media-body-rd"><div class="choice_text"><div class="date"><a class="gad_btn" href="'+ url +'" target="_blank">Business</a><a href="#"><i class="fa fa-calendar" aria-hidden="true"></i>March 14, 2020</a><a href="#"><i class="fa fa-user" aria-hidden="true"></i>'+ aut +'</a></div><a href="'+ url +'" target="_blank"><h4>'+ ttl +'</h4></a><p class="text1">'+ des +'</p></div></div></div>'
  
  document.getElementById("sub-a").innerHTML += str;
  }
      
  }							
  } catch(e){
  throw Error(e);
  }
}
asub();


//sub blog
async function suba() {
  // Selecting the input element and get its value 
const URL = `https://gnews.io/api/v4/top-headlines?country=in&topic=breaking-news&token=d2ae7f9ba90d44f86d9debd61bf307be`;
try {
const fetchResult = fetch(URL)
const response = await fetchResult;
const jsonData = await response.json();
console.log(jsonData);

var ttl = "",
url = "",
des = "",
imgurl = "";
aut= "";
var str, i=0;
for (var i in jsonData.articles)
{
if(i <=7){
    url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
des = jsonData.articles[i].description;
imgurl = jsonData.articles[i].image;
aut= jsonData.articles[i].source.name

str= '<div class="row pb-3"><div class="col-5 align-self-center"><img src="'+imgurl +'" alt="img" class="fh5co_most_trading"/></div><div class="col-7 paddding"> <a href="'+ url +'" target="_blank"><div class="most_fh5co_treding_font">'+ ttl +'</div></a><div class="most_fh5co_treding_font_123"> Sep 14 2020</div></div></div>'

document.getElementById("sub-b").innerHTML += str;
}
    
}							
} catch(e){
throw Error(e);
}
}
suba();   

//Trending
async function thi() {
  // Selecting the input element and get its value 
const URL = `https://gnews.io/api/v4/top-headlines?country=in&topic=world&token=d2ae7f9ba90d44f86d9debd61bf307be`;
try {
const fetchResult = fetch(URL)
const response = await fetchResult;
const jsonData = await response.json();
console.log(jsonData);

var ttl = "",
url = "",
des = "",
imgurl = "";
aut= "";
var str, i=0;
for (var i in jsonData.articles)
{
if(i <=0){
url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
des = jsonData.articles[i].description;
imgurl = jsonData.articles[i].image;
aut= jsonData.articles[i].source.name

// str= '<div class="row pb-3"><div class="col-5 align-self-center"><img src="'+imgurl +'" alt="img" class="fh5co_most_trading"/></div><div class="col-7 paddding"> <a href="'+ url +'" target="_blank"><div class="most_fh5co_treding_font">'+ ttl +'</div></a><div class="most_fh5co_treding_font_123"> March 2020</div></div></div>'
 str1='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+imgurl+'" alt=""/></div><div><a href="'+url+'" class="d-block fh5co_small_post_heading"><span class="">'+ttl+'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>'
document.getElementById("tree1").innerHTML += str1;
}
  else if(i <=1){
url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
imgurl = jsonData.articles[i].image;
str2='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+imgurl+'" alt=""/></div><div><a href="'+url+'" class="d-block fh5co_small_post_heading"><span class="">'+ttl+'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>'
document.getElementById("tree2").innerHTML += str2;   
  }  
  else if(i <=2){
url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
imgurl = jsonData.articles[i].image;
str3='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+imgurl+'" alt=""/></div><div><a href="'+url+'" class="d-block fh5co_small_post_heading"><span class="">'+ttl+'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>'
document.getElementById("tree3").innerHTML += str3;   
  } 
  else if(i <=3){
url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
imgurl = jsonData.articles[i].image;
str4='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+imgurl+'" alt=""/></div><div><a href="'+url+'" class="d-block fh5co_small_post_heading"><span class="">'+ttl+'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>'
document.getElementById("tree4").innerHTML += str4;   
  } 
  else if(i <=4){
url = jsonData.articles[i].url;
ttl = jsonData.articles[i].title;
imgurl = jsonData.articles[i].image;
str5='<div class="fh5co_hover_news_img"><div class="fh5co_news_img"><img src="'+imgurl+'" alt=""/></div><div><a href="'+url+'" class="d-block fh5co_small_post_heading"><span class="">'+ttl+'</span></a><div class="c_g"><i class="fa fa-clock-o"></i> Sep 14,2020</div></div></div>'
document.getElementById("tree5").innerHTML += str5;   
  } 
}							
} catch(e){
throw Error(e);
}
}
thi();   
async function cato1() {
  const URL = `https://gnews.io/api/v4/top-headlines?country=in&topic=breaking-news&token=d2ae7f9ba90d44f86d9debd61bf307be`;
   try {
   const fetchResult = fetch(URL)
   const response = await fetchResult;
   const jsonData = await response.json();
   console.log(jsonData);
   
   var ttl = "",
   url = "",
   des = "",
   imgurl = "";
   var str, i=1;
   for (var i in jsonData.articles)
   {
   if(i <=8){
       url = jsonData.articles[i].url;
   ttl = jsonData.articles[i].title;
   des = jsonData.articles[i].description;
   imgurl = jsonData.articles[i].image;
   str1= '<a href="#" class="footer_img_post_6"><img src="'+ imgurl+'" alt="img"/></a>'
   document.getElementById("foot1").innerHTML += str1;
   }
       
   }							
   } catch(e){
   throw Error(e);
   }
 }
 cato1();